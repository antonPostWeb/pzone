<?php

class Notification extends \Eloquent {
    
protected $table = 'notifications';
}
