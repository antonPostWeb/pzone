<?php

class Useremergencyexit extends \Eloquent {
    
protected $table = 'users_emergency_exit';
}
 
