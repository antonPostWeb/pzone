<?php

class Request_attachment extends \Eloquent {
    
    protected $table = 'request_attachments';
}