<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="utf-8">
    </head>
    <body>
        <h2>Welcome to my site</h2>
 
        <div>
            Your sign up details are below:
        </div>
        <div>{{ $detail }}</div>
        <div>{{ $name}} </div>
    </body>
</html>